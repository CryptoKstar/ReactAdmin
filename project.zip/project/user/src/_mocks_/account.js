const account = {
  // displayName: JSON.parse(sessionStorage.UserData).Name,
  // email: JSON.parse(sessionStorage.UserData).Email,
  photoURL: '/static/mock-images/avatars/avatar_default.jpg'
};

export default account;
